<?php
include('database.inc.php');
$msg = "";
if(isset ($_POST['submit'])){
    $name = mysqli_real_escape_string($con,$_POST['firstname']);
    $email = mysqli_real_escape_string($con,$_POST['email']);
    $mobile = mysqli_real_escape_string($con,$_POST['mobile']);
    $comment = mysqli_real_escape_string($con,$_POST['messages']);
    
    mysqli_query ($con, "insert into contact_us(name,email,mobile,comment) values('$name','$email','$mobile','$comment')");
    $msg = "thanks for ragister";
    
    $html="<table><tr><td>Name</td><td>$name</td></tr><tr><td>Email</td><td>$email</td></tr><tr><td>Mobile</td><td>$mobile</td></tr><tr><td>Comment</td><td>$comment</td></tr></table>";


include ('smtp/PHPMailerAutoload.php');
    $mail = new PHPMailer(true);
    $mail=new PHPMailer(true);
	$mail->isSMTP();
	$mail->Host="smtp.gmail.com";
	$mail->Port=587;
	$mail->SMTPSecure="tls";
	$mail->SMTPAuth=true;
	$mail->Username=" suraj.weberleads@gmail.com";
	$mail->Password=" Weber123";
	$mail->SetFrom("suraj.weberleads@gmail.com");
	$mail->addAddress("suraj.weberleads@gmail.com");
    $mail->IsHTML(true);
	$mail->Subject="New Contact Us";
	$mail->Body=$html;
	$mail->SMTPOptions=array('ssl'=>array(
		'verify_peer'=>false,
		'verify_peer_name'=>false,
		'allow_self_signed'=>false
	));
    
    if($mail->send()){
		echo "mail send to the admin will be call you after sum time";
	}else{
		echo "Error occur";
	}
	echo $msg;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact form</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
   
   <section>
       <div class="container">
          <form action="" method="post">
              <div class="form-group">
                 <lable for = "firstname">First Name</lable>
               <input type="text" id="firstname" name="firstname" required>
              </div>
                            
              <div class="form-group">
                 <lable for = "lastname">Email</lable>
               <input type="email" id="email" name="email" required>
              </div>
              <div class="form-group">
                 <lable for = "lastname">Mobile Number</lable>
               <input type="text" id="lastname" name="mobile" required>
              </div>
              
              <div class="form-group">
                 <lable for = "lastname">Messages</lable>
                 <textarea name="messages" id="messages" cols="30" rows="10" required></textarea>
              </div>
              <button type="submit" name="submit">Submit</button><span style="color:red;" id="msg" ><?php $msg ?></span>
          </form>
          
       </div>
        
     <!--  <div id="status" class="error">Success</div>--> 
   </section>
    
</body>
</html>